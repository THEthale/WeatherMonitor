package com.weather.WeatherMonitoringSystem.service;

import com.weather.WeatherMonitoringSystem.model.Alert;
import com.weather.WeatherMonitoringSystem.repository.AlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertService {
    @Autowired
    private AlertRepository alertRepository;

    // Save an alert to the repository
    public void saveAlert(Alert alert) {
        alertRepository.save(alert);
    }

    // Fetch all alerts from the repository
    public List<Alert> getAllAlerts() {
        return alertRepository.findAll();
    }

    // Fetch alerts by condition
    public List<Alert> getAlertsByCondition(String condition) {
        return alertRepository.findByCondition(condition);
    }

    // Fetch alerts by time range (e.g., last X minutes/hours)
    public List<Alert> getAlertsByTimeRange(long startTime, long endTime) {
        return alertRepository.findByTimestampBetween(startTime, endTime);
    }

    // Check if an alert already exists for a given condition within a certain time frame
    public boolean alertExists(String condition, long currentTimestamp) {
        long timeFrame = 60 * 1000; // Check within the last minute
        List<Alert> existingAlerts = alertRepository.findByConditionAndTimestampAfter(condition, currentTimestamp - timeFrame);
        return !existingAlerts.isEmpty();
    }
}
