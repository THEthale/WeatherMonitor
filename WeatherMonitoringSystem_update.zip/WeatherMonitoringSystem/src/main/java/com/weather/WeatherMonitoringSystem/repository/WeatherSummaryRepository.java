package com.weather.WeatherMonitoringSystem.repository;

import com.weather.WeatherMonitoringSystem.model.DailyWeatherSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface WeatherSummaryRepository extends JpaRepository<DailyWeatherSummary, Long> {
    DailyWeatherSummary findByDate(LocalDate date);
}
