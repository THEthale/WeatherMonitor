package com.weather.WeatherMonitoringSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.weather.WeatherMonitoringSystem.model.Alert;
import com.weather.WeatherMonitoringSystem.model.DailyWeatherSummary;
import com.weather.WeatherMonitoringSystem.model.Thresholds;
import com.weather.WeatherMonitoringSystem.model.WeatherData;
import com.weather.WeatherMonitoringSystem.repository.AlertRepository;
import com.weather.WeatherMonitoringSystem.repository.DailyWeatherSummaryRepository;
import com.weather.WeatherMonitoringSystem.repository.ThresholdRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WeatherService {
    private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather?q={city}&appid=ec0d50725058fd39f8b021f77d88b634&units=metric";
    private static final Logger logger = LoggerFactory.getLogger(WeatherService.class);

    @Value("${weather.api.key}")
    private String apiKey;

    @Autowired
    private RestTemplate restTemplate; // Injecting RestTemplate

    @Autowired
    private DailyWeatherSummaryRepository summaryRepository;

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private ThresholdRepository thresholdRepository;

    private Map<String, DailyWeatherSummary> dailyWeatherMap = new HashMap<>();
    private LocalDate currentDate;
    private int temperatureCount = 0;
    private double totalTemperature = 0;

    private Map<String, List<Double>> dailyTemperatureMap = new HashMap<>(); // To store temperatures per city
    private Map<String, Map<String, Integer>> dailyConditionCount = new HashMap<>(); // To store condition counts



    public WeatherData getWeatherByCity(String city) {
        try {
            return restTemplate.getForObject(API_URL, WeatherData.class, city, apiKey);
        } catch (Exception e) {
            logger.error("Failed to fetch weather data for {}: {}", city, e.getMessage());
            return null;
        }
    }
    public void simulateWeatherUpdates(int daysToSimulate) {
        String[] cities = {"Delhi", "Mumbai", "Chennai", "Bangalore", "Kolkata", "Hyderabad"};

        for (int day = 0; day < daysToSimulate; day++) {
            LocalDate simulatedDate = LocalDate.now().plus(day, ChronoUnit.DAYS); // Simulated date for each day
            dailyWeatherMap.clear(); // Clear the map for each day's simulation
            temperatureCount = 0;
            totalTemperature = 0;

            for (String city : cities) {
                try {
                    WeatherData weatherData = fetchWeatherData(city, "metric"); // Fetching in Celsius by default
                    processWeatherData(city, weatherData, simulatedDate); // Process with simulated date
                } catch (Exception e) {
                    logger.error("Failed to fetch weather data for {} on {}: {}", city, simulatedDate, e.getMessage());
                }
            }
            saveDailySummary(); // Save the summary after each simulated day's data
        }
    }

    private void processWeatherData(String city, WeatherData data, LocalDate date) {
        if (data == null || data.getMain() == null) {
            return;
        }

        double temperature = data.getMain().getTemp();
        String condition = data.getWeather()[0].getMain();

        if (currentDate == null || !currentDate.equals(date)) {
            currentDate = date;
            dailyWeatherMap.clear();
            temperatureCount = 0;
            totalTemperature = 0;
        }

        DailyWeatherSummary summary = dailyWeatherMap.getOrDefault(city, new DailyWeatherSummary());
        summary.setDate(date);
        totalTemperature += temperature;
        temperatureCount++;

        // Calculate average, max, and min temperatures
        summary.setAvgTemperature(totalTemperature / temperatureCount);
        summary.setMaxTemperature(Math.max(summary.getMaxTemperature(), temperature));
        summary.setMinTemperature(Math.min(summary.getMinTemperature() == 0 ? temperature : summary.getMinTemperature(), temperature));
        summary.setDominantCondition(condition);
        dailyWeatherMap.put(city, summary);

        generateAlerts(city, temperature, condition);
    }
    @Scheduled(fixedRate = 300000) // every 5 minutes
    public void fetchWeatherData() {
        String[] cities = {"Delhi", "Mumbai", "Chennai", "Bangalore", "Kolkata", "Hyderabad"};

        for (String city : cities) {
            try {
                WeatherData weatherData = restTemplate.getForObject(API_URL, WeatherData.class, city, apiKey, "metric"); // Default to metric
                processWeatherData(city, weatherData);
            } catch (Exception e) {
                logger.error("Failed to fetch weather data for {}: {}", city, e.getMessage());
            }
        }
        saveDailySummary();
    }

    public WeatherData fetchWeatherData(String city, String unit) {
        // If the user chooses Kelvin, OpenWeatherMap does not require the 'units' parameter
        if (unit.equalsIgnoreCase("kelvin")) {
            String apiUrl = "https://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}";
            return restTemplate.getForObject(apiUrl, WeatherData.class, city, apiKey);
        }
        // For Celsius (metric) or Fahrenheit (imperial)
        return restTemplate.getForObject(API_URL, WeatherData.class, city, apiKey, unit);
    }

    private void processWeatherData(String city, WeatherData data) {
        if (data == null || data.getMain() == null) {
            return;
        }

        double temperature = data.getMain().getTemp();
        String condition = data.getWeather()[0].getMain();
        LocalDate today = LocalDate.now();

        if (currentDate == null || !currentDate.equals(today)) {
            // New day, save the previous day summary and reset
            saveDailySummary();
            currentDate = today;
            dailyTemperatureMap.clear();
            dailyConditionCount.clear();
        }

        // Add temperature data
        dailyTemperatureMap.putIfAbsent(city, new ArrayList<>());
        dailyTemperatureMap.get(city).add(temperature);

        // Count occurrences of each condition
        dailyConditionCount.putIfAbsent(city, new HashMap<>());
        dailyConditionCount.get(city).merge(condition, 1, Integer::sum);
    }

    private void generateAlerts(String city, double temperature, String condition) {
        Thresholds thresholds = thresholdRepository.findAll().stream().findFirst().orElse(null);
        if (thresholds == null) {
            logger.warn("No thresholds set. Please configure thresholds before generating alerts.");
            return;
        }

        if (temperature > thresholds.getTemperatureThreshold()) {
            createAlert("High Temperature", city + " is experiencing very high temperatures!");
        } else if (condition.equalsIgnoreCase("Rain")) {
            createAlert("Rain Alert", city + " is experiencing rain.");
        }
    }

    private void createAlert(String condition, String message) {
        Alert alert = new Alert();
        alert.setCondition(condition);
        alert.setMessage(message);
        alert.setTimestamp(System.currentTimeMillis());
        alertRepository.save(alert);
    }

    private void saveDailySummary() {
        for (String city : dailyTemperatureMap.keySet()) {
            List<Double> temperatures = dailyTemperatureMap.get(city);

            double avgTemperature = temperatures.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            double maxTemperature = temperatures.stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
            double minTemperature = temperatures.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);

            // Determine dominant condition
            Map<String, Integer> conditionCount = dailyConditionCount.get(city);
            String dominantCondition = conditionCount.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey)
                    .orElse("Unknown");

            // Create and save daily summary
            DailyWeatherSummary summary = new DailyWeatherSummary();
            summary.setDate(currentDate);
            summary.setAvgTemperature(avgTemperature);
            summary.setMaxTemperature(maxTemperature);
            summary.setMinTemperature(minTemperature);
            summary.setDominantCondition(dominantCondition);

            summaryRepository.save(summary);
        }
    }

}
