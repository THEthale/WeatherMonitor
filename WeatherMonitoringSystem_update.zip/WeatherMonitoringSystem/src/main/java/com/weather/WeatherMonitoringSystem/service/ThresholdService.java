package com.weather.WeatherMonitoringSystem.service;

import com.weather.WeatherMonitoringSystem.model.Thresholds;
import com.weather.WeatherMonitoringSystem.repository.ThresholdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ThresholdService {
    @Autowired
    private ThresholdRepository thresholdRepository;

    public void saveThresholds(Thresholds thresholds) {
        thresholdRepository.save(thresholds);
    }

    public List<Thresholds> getAllThresholds() {
        return thresholdRepository.findAll();
    }
}
