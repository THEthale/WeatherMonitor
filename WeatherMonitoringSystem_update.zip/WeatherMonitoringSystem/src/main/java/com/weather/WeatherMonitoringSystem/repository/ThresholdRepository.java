package com.weather.WeatherMonitoringSystem.repository;

import com.weather.WeatherMonitoringSystem.model.Thresholds;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ThresholdRepository extends JpaRepository<Thresholds, Long> {
}
