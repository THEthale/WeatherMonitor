package com.weather.WeatherMonitoringSystem.repository;

import com.weather.WeatherMonitoringSystem.model.Alert;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlertRepository extends JpaRepository<Alert, Long> {
    List<Alert> findByCondition(String condition);
    List<Alert> findByTimestampBetween(long startTime, long endTime);
    List<Alert> findByConditionAndTimestampAfter(String condition, long timestamp);
}
