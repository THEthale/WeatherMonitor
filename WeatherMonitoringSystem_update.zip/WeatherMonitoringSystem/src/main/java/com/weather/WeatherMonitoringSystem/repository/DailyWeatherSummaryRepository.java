package com.weather.WeatherMonitoringSystem.repository;

import com.weather.WeatherMonitoringSystem.model.DailyWeatherSummary;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Optional;

public interface DailyWeatherSummaryRepository extends JpaRepository<DailyWeatherSummary, Long> {
    Optional<DailyWeatherSummary> findByCityAndDate(String city, LocalDate date); // Updated method signature
}
