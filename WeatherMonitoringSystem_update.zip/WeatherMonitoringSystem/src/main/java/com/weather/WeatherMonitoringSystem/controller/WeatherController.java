package com.weather.WeatherMonitoringSystem.controller;

import com.weather.WeatherMonitoringSystem.model.Alert;
import com.weather.WeatherMonitoringSystem.model.DailyWeatherSummary;
import com.weather.WeatherMonitoringSystem.model.Thresholds;
import com.weather.WeatherMonitoringSystem.model.WeatherData;
import com.weather.WeatherMonitoringSystem.repository.DailyWeatherSummaryRepository;
import com.weather.WeatherMonitoringSystem.service.AlertService;
import com.weather.WeatherMonitoringSystem.service.ThresholdService;
import com.weather.WeatherMonitoringSystem.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @GetMapping("/{city}")
    public WeatherData getWeatherData(@PathVariable String city,
                                      @RequestParam(defaultValue = "metric") String unit) {
        return weatherService.fetchWeatherData(city, unit);
    }

    @Autowired
    private ThresholdService thresholdService;

    @Autowired
    private AlertService alertService;


    // Endpoint to set thresholds
    @PostMapping("/thresholds")
    public void setThresholds(@RequestBody Thresholds thresholds) {
        thresholdService.saveThresholds(thresholds);
    }

    // Endpoint to get all thresholds
    @GetMapping("/thresholds")
    public List<Thresholds> getAllThresholds() {
        return thresholdService.getAllThresholds();
    }

    // Endpoint to create alerts
    @PostMapping("/alerts")
    public void createAlert(@RequestBody Alert alert) {
        alertService.saveAlert(alert);
    }

    // Endpoint to get all alerts
    @GetMapping("/alerts")
    public List<Alert> getAllAlerts() {
        return alertService.getAllAlerts();
    }

    // Endpoint to fetch weather data from OpenWeatherMap API
    @GetMapping("/fetch")
    public WeatherData fetchWeatherData(@RequestParam String city, @RequestParam String unit) {
        WeatherData weatherData = weatherService.fetchWeatherData(city, unit);
        if (weatherData == null) {
            throw new RuntimeException("Weather data not found for city: " + city);
        }
        return weatherData;
    }

    @GetMapping("/simulateWeatherUpdates")
    public String simulateWeatherUpdates(@RequestParam int days) {
        weatherService.simulateWeatherUpdates(days);
        return "Simulation complete for " + days + " days.";
    }

    @GetMapping("/city")
    public WeatherData getWeatherByCity(@RequestParam String city) {
        return weatherService.getWeatherByCity(city);
    }

    @Autowired
    private DailyWeatherSummaryRepository summaryRepository;

    @GetMapping("/daily-summary")
    public DailyWeatherSummary getDailySummary(@RequestParam String city, @RequestParam LocalDate date) {
        return summaryRepository.findByCityAndDate(city, date).orElse(null);
    }



}
