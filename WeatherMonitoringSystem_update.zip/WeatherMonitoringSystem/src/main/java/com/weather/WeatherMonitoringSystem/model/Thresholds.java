package com.weather.WeatherMonitoringSystem.model;

import jakarta.persistence.*;


@Entity
public class Thresholds {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Use AUTO or TABLE if needed
    private Long id;

    private double temperatureThreshold;
    private String weatherCondition;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getTemperatureThreshold() {
        return temperatureThreshold;
    }

    public void setTemperatureThreshold(double temperatureThreshold) {
        this.temperatureThreshold = temperatureThreshold;
    }

    public String getWeatherCondition() {
        return weatherCondition;
    }

    public void setWeatherCondition(String weatherCondition) {
        this.weatherCondition = weatherCondition;
    }
}
