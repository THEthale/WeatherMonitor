package com.weather.WeatherMonitoringSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherMonitoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
